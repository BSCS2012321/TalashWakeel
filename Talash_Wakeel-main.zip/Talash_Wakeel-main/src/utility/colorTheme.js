export const inputLabel = "#666666";
export const primaryColour = "#007dfe"