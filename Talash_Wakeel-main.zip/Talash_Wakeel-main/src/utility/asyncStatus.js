export const asyncStatus = {
    IDLE: "idle",
    LOADING: "loading",
    SUCCEEDED: "succeeded",
    ERROR: "error",
  };
  