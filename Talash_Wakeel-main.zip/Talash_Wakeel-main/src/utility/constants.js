export const user_type_constant = {
    LAWYER: "lawyer",
    FIRM: "firm",
    CLIENT: "client",
  }