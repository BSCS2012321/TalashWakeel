export const lawyerTypes = [
    "All",
    "Tax Lawyer",
    "Family Lawyer",
    "Criminal Lawyer",
    "Corporate Lawyer",
    "Bankruptcy Lawyer",
    "Employment Lawyer",
    "Real Estate Lawyer",
    "Civil Rights Lawyer",
    "Environmental Lawyer",
    "Personal Injury Lawyer",
    "Intellectual Property Lawyer",
]