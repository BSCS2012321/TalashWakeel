import React from 'react'
import Header from '../../../components/Header'

export const FirmSettings = () => {
  return (
    <div>
      <Header title="Settings" />
    </div>
  )
}
