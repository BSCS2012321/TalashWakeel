import React from 'react'
import Header from '../../../components/Header'
import { AddDocuments } from '../../../components/AddDocument'

export const FirmDocuments = () => {
  return (
    <div>
      <AddDocuments />
    </div>
  )
}
